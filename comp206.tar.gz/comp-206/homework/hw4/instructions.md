# COMP 206 - Fall 2025 - Homework 4: basics of C programming

This one is short!

## Part 1: compiling a program

- Write a bash script called `build` that uses `gcc` to compile a file called `main.c` into an executable named `meow`.
- Ensure that the script `build` has the execute permission enabled.

## Part 2: writing a simple program

- You'll now implement the program `meow`, which will be similar to `cat`.
- Write all your code in the file `main.c`.
- This assignment is a fill-in-the-blanks.
- Some starter code is provided in `main.c` for you, because you don't know much C yet.
- The remaining instructions are in the code.
