import assignment2.*;

public class Main {
    public static void main(String[] args) {
        // System.out.println("hello world");
        // Deck deck = new Deck(4, 3);
        // Deck.Card current = deck.head;
        // do {
        //     System.out.print(current.toString() + " ");
        //     current = current.next;
        // } while(current != deck.head);

        // System.out.println("");
        // Deck deck2 = new Deck(deck);
        // current = deck2.head;
        // do {
        //     System.out.print(current.toString() + " ");
        //     current = current.next;
        // } while(current != deck2.head);

        // char letter = 'a';
        // int letter2 = (int) letter;
        // System.out.println(letter2);
        Deck.gen.setSeed(10);

        Deck deck1 = new Deck(5, 2);
        printDeck(deck1);

        deck1.shuffle();

        SolitaireCipher cipher1 = new SolitaireCipher(deck1);

        printDeck(deck1);

        String msg = "Is that you, Bob?";

        // int[] keystream = cipher1.getKeystream(msg.length());
        // for (int i = 0; i < keystream.length; i++) {
        //     System.out.print(keystream[i] + " ");
        // }
        // System.out.println(cipher1.getKeystream(msg.length()));

        System.out.println(cipher1.encode(msg));
    }

    public static void printDeck(Deck d) {
        String[] arr = new String[d.numOfCards];
    
        Deck.Card cursor = d.head;
    
        for (int i = 0; i < d.numOfCards; i++) {
          arr[i] = cursor.toString();
          cursor = cursor.next;
        }
    
        System.out.println("D (" + d.numOfCards + ") [" + String.join(", ", arr) + "]");
    
    }
}

